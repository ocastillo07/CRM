<?php
<object class="uinicio" name="uinicio" baseclass="page">
  <property name="Background"></property>
  <property name="Caption">International de Baja California SA de CV</property>
  <property name="Color">#C0C0C0</property>
  <property name="DocType">dtNone</property>
  <property name="Height">504</property>
  <property name="IsMaster">0</property>
  <property name="Name">uinicio</property>
  <property name="Width">800</property>
  <property name="OnShow">uinicioShow</property>
  <object class="Image" name="Image1" >
    <property name="Autosize">1</property>
    <property name="Border">0</property>
    <property name="Height">252</property>
    <property name="ImageSource">imagenes/international_big.JPG</property>
    <property name="Left">258</property>
    <property name="Link"></property>
    <property name="LinkTarget"></property>
    <property name="Name">Image1</property>
    <property name="Top">164</property>
    <property name="Width">241</property>
  </object>
  <object class="Panel" name="pbotones" >
    <property name="Background">imagenes/bar2.png</property>
    <property name="Height">48</property>
    <property name="Name">pbotones</property>
    <property name="Width">800</property>
  </object>
</object>
?>
