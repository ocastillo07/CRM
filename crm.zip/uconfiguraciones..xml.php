<?php
<object class="uconfiguraciones" name="uconfiguraciones" baseclass="page">
  <object class="Panel" name="pbotones" >
    <object class="Button" name="btnregresar" >
    </object>
    <object class="Button" name="btnguardar" >
    </object>
    <object class="Button" name="btnguardarcerrar" >
    </object>
    <object class="Label" name="lbtitulo" >
    </object>
  </object>
  <object class="Edit" name="edcompra" >
  </object>
  <object class="Edit" name="edventa" >
  </object>
  <object class="Edit" name="edthorton" >
  </object>
  <object class="Edit" name="edrabon" >
  </object>
  <object class="Edit" name="edbus" >
  </object>
  <object class="Edit" name="edtracto" >
  </object>
  <object class="Edit" name="edligero" >
  </object>
  <object class="Label" name="Label1" >
  </object>
  <object class="Label" name="Label2" >
  </object>
  <object class="Label" name="Label3" >
  </object>
  <object class="Label" name="Label4" >
  </object>
  <object class="Label" name="Label5" >
  </object>
  <object class="Label" name="Label6" >
  </object>
  <object class="Label" name="Label7" >
  </object>
  <object class="Label" name="Label8" >
  </object>
  <object class="Label" name="Label9" >
  </object>
  <object class="Label" name="Label10" >
  </object>
  <object class="Label" name="Label11" >
  </object>
  <object class="Memo" name="mofertas" >
  </object>
  <object class="Edit" name="edvendedor" >
  </object>
  <object class="Label" name="Label12" >
  </object>
  <object class="Label" name="Label13" >
  </object>
  <object class="Label" name="Label14" >
  </object>
  <object class="Memo" name="macciones" >
  </object>
  <object class="Label" name="Label15" >
  </object>
  <object class="Label" name="Label16" >
  </object>
  <object class="Memo" name="mrefacciones01" >
  </object>
  <object class="Label" name="Label17" >
  </object>
  <object class="Label" name="Label18" >
  </object>
  <object class="Memo" name="mrefacciones02" >
  </object>
  <object class="Label" name="Label19" >
  </object>
  <object class="Label" name="Label20" >
  </object>
  <object class="Memo" name="mrefacciones03" >
  </object>
  <object class="Label" name="Label21" >
    <property name="Width">195</property>
  </object>
  <object class="Label" name="Label22" >
  </object>
  <object class="Memo" name="msolicitudes" >
  </object>
</object>
?>
