<?php
<object class="Unit1" name="Unit1" baseclass="page">
  <property name="Background"></property>
  <property name="Caption">Unit1</property>
  <property name="DocType">dtNone</property>
  <property name="Height">280</property>
  <property name="IsMaster">0</property>
  <property name="Name">Unit1</property>
  <property name="Width">800</property>
  <property name="OnCreate">Unit1Create</property>
</object>
?>
