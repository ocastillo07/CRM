<?php
<object class="ulogout" name="ulogout" baseclass="page">
  <property name="Background"></property>
  <property name="Caption">Log Out</property>
  <property name="Color">#C0C0C0</property>
  <property name="DocType">dtNone</property>
  <property name="Height">600</property>
  <property name="IsMaster">0</property>
  <property name="Name">ulogout</property>
  <property name="Width">800</property>
  <property name="OnShow">ulogoutShow</property>
  <object class="Label" name="Label1" >
    <property name="Caption">Ir a Login</property>
    <property name="Color">#C0C0C0</property>
    <property name="Font">
        <property name="Size">12</property>
    </property>
    <property name="Height">21</property>
    <property name="Left">24</property>
    <property name="Link">index.php</property>
    <property name="Name">Label1</property>
    <property name="ParentFont">0</property>
    <property name="Top">40</property>
    <property name="Width">75</property>
  </object>
</object>
?>
