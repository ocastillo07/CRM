<?php
<object class="index" name="index" baseclass="page">
  <property name="Background"></property>
  <property name="Caption">INTERNATIONAL DE BAJA CALIFORNIA S.A. DE C.V.</property>
  <property name="DocType">dtNone</property>
  <property name="Height">600</property>
  <property name="IsMaster">0</property>
  <property name="Name">index</property>
  <property name="Width">800</property>
  <object class="Frame" name="Frame1" >
    <property name="Borders">0</property>
    <property name="Height">598</property>
    <property name="Left">1</property>
    <property name="Name">Frame1</property>
    <property name="Resizeable">0</property>
    <property name="Scrolling">fsNo</property>
    <property name="Source">leftpane.php</property>
    <property name="Top">1</property>
    <property name="Width">160</property>
  </object>
  <object class="Frameset" name="Frameset1" >
    <property name="FrameBorder">no</property>
    <property name="Height">598</property>
    <property name="Left">161</property>
    <property name="Name">Frameset1</property>
    <property name="Top">1</property>
    <property name="Width">638</property>
    <object class="Frame" name="Frame3" >
      <property name="Align">alClient</property>
      <property name="Borders">0</property>
      <property name="Height">596</property>
      <property name="Left">1</property>
      <property name="Name">Frame3</property>
      <property name="Top">1</property>
      <property name="Width">636</property>
      <object class="Panel" name="pbotones" >
        <property name="Background">imagenes/bar2.png</property>
        <property name="Dynamic"></property>
        <property name="Height">50</property>
        <property name="Name">pbotones</property>
        <property name="ParentColor">0</property>
        <property name="Width">636</property>
      </object>
    </object>
  </object>
</object>
?>
