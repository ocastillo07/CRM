---------------------------------------------------------------------
|  E-Commerce Example Sample Components for Delphi For PHP          |
|                                                                   |
|  Author: Jonathan Benedicto                                       |
---------------------------------------------------------------------

-- Installation --

Extract this zip into the vcl subdirectory of the Delphi For PHP directory. Then open Delphi For PHP, click the Component menu, click Packages, and then click Add. Navigate to the Delphi For PHP\vcl\packages directory, and select the jbsamples.package.php file.

This will install the sample components into the IDE.